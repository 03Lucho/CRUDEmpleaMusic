<br>
<nav style="margin-left: 5%">
    <li class="li1" style="margin-bottom: 10px"><a class="amenu" href={{route('profesores.index')}} style="text-decoration: none">Profesores</a></li>
    
    <li class="li1" style="margin-bottom: 10px"><a class="amenu" href={{route('admins.index')}} style="text-decoration: none">Administradores</a></li>

    <li class="li1" style="margin-bottom: 10px"><a class="amenu" href={{route('profesores.createperfil')}} style="text-decoration: none">Crear perfil profesor</a></li>
</nav>
<div style="text-align: center; position-absolute: 50%">
    <form action="<?php echo e(route('profesores.perfilupdate',$profesor->idprofesor)); ?>"method='put'>
        <?php echo csrf_field(); ?>
        <div>
        </div>
        <label for="">Nombre</label>
        <input type="text" name="nombre" id="" value="<?php echo e($profesor->nombre); ?>">
        <label for="">Apellido</label>
        <input type="text" name="apellido" id="" value="<?php echo e($profesor->apellido); ?>">
        <label for="">Imagen de perfil</label>
        <input type="file" name="imagen" id="">
        <label for="">Email</label>
        <input type="text" name="email" id="" value="<?php echo e($profesor->email); ?>">
        <label for="">Telefono</label>
        <input type="number" name="telefono" id="" value="<?php echo e($profesor->telefono); ?>">
        <label for="">Descripcion</label>
        <input type="text" name="descripcion" id="" value="<?php echo e($profesor->descripcion); ?>">
        <label for="">Años de experiencia</label>
        <input type="number" name="aniosexperiencia" id="" value="<?php echo e($profesor->aniosexperiencia); ?>">
        <label for="">Especialidad</label>
        <input type="text" name="especialidad" id="" value="<?php echo e($profesor->especialidad); ?>">
        <br><br>
        <button>Actualizar</button>
        </div>
        
    </form>
</div><?php /**PATH C:\laragon\www\empleamusic\resources\views/profesores/editperfil.blade.php ENDPATH**/ ?>
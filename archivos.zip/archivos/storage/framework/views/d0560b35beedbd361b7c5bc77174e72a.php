<br>
<br>
<br>
<br>
<div style="text-align: center; position-absolute: 50%">
    <form action="<?php echo e(route('profesores.store')); ?>"method='POST'>
        <?php echo csrf_field(); ?>
        <div>
            <label for="idinstrumento">Seleccione el instrumento que va a esneñar</label>
            <select name="instrument">
                <?php $__empty_1 = true; $__currentLoopData = $instrumento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instrum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
                <option value="<?php echo e($instrum->idinstrumento); ?>" > <?php echo e($instrum->nombre); ?></option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>
        <br>
        <div>
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="mombre">
            <label for="descripcion">Descripcion</label>
            <input type="text" name="descripcion" id="descripcion">
            <label for="costo">Costo</label>
            <input type="text" name="costo" id="costo">
            <label for="disponibilidad">Disponibilidad</label>
            <input type="text" name="disponibilidad" id="disponibilidad">
        </div>
        <br>
        <button>Enviar</button>
    </form>
</div><?php /**PATH C:\laragon\www\empleamusic\resources\views/profesores/clasecreate.blade.php ENDPATH**/ ?>
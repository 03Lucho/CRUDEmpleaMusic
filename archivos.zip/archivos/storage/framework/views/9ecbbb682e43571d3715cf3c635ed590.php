
<br>
<br>
<div style="text-align: center; position:absolute:50%">
<a href=<?php echo e(route ('profesores.create')); ?>><button >Crear clase</button></a> <br><br>
<a href=<?php echo e(route ('profesores.solicitudes')); ?>><button >Solicitudes</button></a> <br><br>
<a href=<?php echo e(route ('profesores.perfill')); ?>><button >Perfil</button></a> <br>
<br>
<br>
<h2>Mis clases creadas</h2>
<div style=" text-align: center">
    <table style="margin:2%;text-align: center; border:2px solid black">
        <tr>
            <td style="border:2px solid black; padding:5px">Nombre</td>
            <td style="border:2px solid black; padding:5px">Instrumento</td>
            <td style="border:2px solid black; padding:5px">Descripcion</td>
            <td style="border:2px solid black; padding:5px">Disponibilidad</td>
            <td style="border:2px solid black; padding:5px">Costo</td>
            <td style="text-align: center; border:2px solid black;padding:5px " colspan="3">Acciones</td>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $clase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($class->nombre); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($class->nomins); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($class->descripcion); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($class->disponibilidad); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($class->costo); ?></td>

            <td>
            <a href="<?php echo e(route('profesores.editarclases',$class->idclase)); ?>" ><button>Editar</button></a>
            </td>
            <td>
                <a href="<?php echo e(route('profesores.destroyclass',$class->idclase)); ?>"onclick="return confirm('¿Estas seguro de eliminar la clase?')"><button>Eliminar</button></a>
            </td>
            <td>
                <a href="<?php echo e(route('profesores.showagen',$class->idclase)); ?>"><button>Ver agendas</button></a>
            </td>
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </table>
</div>
 <div style="text-align: center; margin-top:2%">
    <a href=<?php echo e(route ('profesores.createcomentario')); ?>><button >Realizar comentario</button></a>
</div>
<?php /**PATH C:\laragon\www\empleamusic\resources\views/profesores/index.blade.php ENDPATH**/ ?>

<br>
<br>
<div style="text-align: center; position:absolute:50%">
<br>
<br>
<h2>Solicitudes</h2>
<div style=" text-align: center">
    <table style="margin:2%;text-align: center; border:2px solid black">
        <tr>
            <td style="border:2px solid black; padding:5px">Nombre Aprendiz</td>
            <td style="border:2px solid black; padding:5px">Nombre Clase</td>
            <td style="border:2px solid black; padding:5px">Fecha Agendada</td>
            <td style="border:2px solid black; padding:5px">Agenda Realizada El:</td>
            <td style="border:2px solid black; padding:5px">Descripcion</td>
            <td style="text-align: center; border:2px solid black;padding:5px " colspan="2">Acciones</td>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $solicitudagenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($solic->nomapren); ?></td>
            <td  style="border-right:2px solid black; padding:10px"><?php echo e($solic->nomclas); ?></td>
            <td name="fechaagendada" style="border-right:2px solid black; padding:10px"><?php echo e($solic->fechaagendada); ?></td>
            <td name="fechahora" style="border-right:2px solid black; padding:10px"><?php echo e($solic->fechahora); ?></td>
            <td name="descripcion" style="border-right:2px solid black; padding:10px"><?php echo e($solic->descripcion); ?></td>

            <td>
                <form action="<?php echo e(route('profesores.confirmstore', ['id1' => $solic->idaprendiz, 'id2' => $solic->idclase, 'id3' => $solic->fechaagendada, 'id4' => $solic->fechahora, 'id5' => $solic->descripcion, 'id6' => $solic->idsolicitudagenda ])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit">Aceptar</button>
                </form>
            </td>
            <td>
                <a href="<?php echo e(route('profesores.rechazo',$solic->idsolicitudagenda)); ?>"><button>Rechazar</button></a>
            </td>
            
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </table>
</div>

<?php /**PATH C:\laragon\www\empleamusic\resources\views/profesores/solicitudes.blade.php ENDPATH**/ ?>
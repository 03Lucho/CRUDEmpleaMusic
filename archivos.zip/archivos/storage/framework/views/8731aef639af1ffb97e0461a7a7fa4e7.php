<br>
<h1>Perfil</h1>
<br>
<br>
<div style=" text-align: center">
    <table style="margin:2%;text-align: center; position:relative;left:25%; border:2px solid black">
        <tr>
            <td style="border:2px solid black; padding:5px">Foto de perfil</td>
            <td style="border:2px solid black; padding:5px">Nombre</td>
            <td style="border:2px solid black; padding:5px">Apellido</td>
            <td style="border:2px solid black; padding:5px">Email</td>
            <td style="border:2px solid black; padding:5px">Telefono</td>
            <td style="border:2px solid black; padding:5px">Descripcion</td>
            <td style="border:2px solid black;padding:5px " >Años de experiencia</td>
            <td style="border:2px solid black;padding:5px " >Especialidad</td>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $profesor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
            <td style="border-right:2px solid black; padding:10px"><img src="<?php echo e(asset('storage/perfil_profesores/' . $prof->imagen)); ?>" alt="foto de perfil" width="100"></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($prof->nombre); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($prof->apellido); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($prof->email); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($prof->telefono); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($prof->descripcion); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($prof->aniosexperiencia); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($prof->especialidad); ?></td>

           
            <a href="<?php echo e(route('profesores.editarperfil',$prof->idprofesor)); ?>"><button>Editar Perfil</button></a>
            
            
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </table>
</div>
 
<?php /**PATH C:\laragon\www\empleamusic\resources\views/profesores/perfil.blade.php ENDPATH**/ ?>
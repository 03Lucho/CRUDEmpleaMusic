<br>
<br>
<h1>Comentario</h1>
<br>
<br>
<div style="text-align: center; position-absolute: 50%">
    <form action="<?php echo e(route('profesores.comentarstore')); ?>"method='POST'>
        <?php echo csrf_field(); ?>
        <br>
        <div>
            <label for="descripcion">Digite su comentario</label>
            <input type="text" size="50" name="descripcion" id="descripcion">
            <br><br>
            
            <br><br>
            <label for="tipo">Tipo de comentario (Queja, Reclamo o Sugerencia)</label>
            <input type="text" name="tipo" id="tipo">
        </div>
        <br>
        <button>Enviar</button>
    </form>
</div><?php /**PATH C:\laragon\www\empleamusic\resources\views/profesores/comentario.blade.php ENDPATH**/ ?>
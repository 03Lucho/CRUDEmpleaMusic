<br>
<br>
<br>
<br>
<div style="text-align: center; position-absolute: 50%">
    <form action="<?php echo e(route('profesores.updateclass',$clase->idclase)); ?>"method='put'>
        <?php echo csrf_field(); ?>
        <div>
            <label for="">Seleccione el instrumento que va a esneñar</label>
            <select name="idinstrumento" id="">
                <?php $__empty_1 = true; $__currentLoopData = $instrumento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instrum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($clase->idinstrumento==$instrum->idinstrumento): ?>
                <option value="<?php echo e($instrum->idinstrumento); ?>" selected><?php echo e($instrum->nombre); ?></option>
                <?php else: ?> 
                <option value="<?php echo e($instrum->idinstrumento); ?>"><?php echo e($instrum->nombre); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
        </div>
        <br>
        <div>
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="mombre" value="<?php echo e($clase->nombre); ?>">
            <label for="descripcion">Descripcion</label>
            <input type="text" name="descripcion" id="descripcion" value="<?php echo e($clase->descripcion); ?>">
            <label for="costo">Costo</label>
            <input type="text" name="costo" id="costo" value="<?php echo e($clase->costo); ?>">
            <label for="disponibilidad">Disponibilidad</label >
            <input type="text" name="disponibilidad" id="disponibilidad" value="<?php echo e($clase->disponibilidad); ?>">
        </div>
        <br>
        <button>Actualizar</button>
    </form>
</div><?php /**PATH C:\laragon\www\empleamusic\resources\views/profesores/editarclase.blade.php ENDPATH**/ ?>
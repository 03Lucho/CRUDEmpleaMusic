<br>
<h1 style="text-align: center">Perfil Aprendiz</h1>
<br>
<br>
<div style=" text-align: center">
    <table style="margin:2%;text-align: center; position:relative;left:10%; border:2px solid black">
        <tr>
            <td style="border:2px solid black; padding:5px">Imagen</td>
            <td style="border:2px solid black; padding:5px">Nombre</td>
            <td style="border:2px solid black; padding:5px">Apellido</td>
            <td style="border:2px solid black; padding:5px">Email</td>
            <td style="border:2px solid black; padding:5px">Telefono</td>
            <td style="border:2px solid black; padding:5px">Descripcion</td>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $aprendizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apren): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($apren->imagen); ?></td>    
            <td style="border-right:2px solid black; padding:10px"><?php echo e($apren->nombre); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($apren->apellido); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($apren->email); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($apren->telefono); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($apren->descripcion); ?></td>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </table>
</div>
 
<?php /**PATH C:\laragon\www\empleamusic\resources\views/profesores/perfilesagendados.blade.php ENDPATH**/ ?>
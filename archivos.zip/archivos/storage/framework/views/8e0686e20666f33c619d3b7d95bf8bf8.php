<br>
<nav style="margin-left: 5%">
    <li class="li1" style="margin-bottom: 10px"><a class="amenu" href=<?php echo e(route('profesores.index')); ?> style="text-decoration: none">Profesores</a></li>
    
    <li class="li1" style="margin-bottom: 10px"><a class="amenu" href=<?php echo e(route('admins.index')); ?> style="text-decoration: none">Administradores</a></li>

    <li class="li1" style="margin-bottom: 10px"><a class="amenu" href=<?php echo e(route('profesores.createperfil')); ?> style="text-decoration: none">Crear perfil profesor</a></li>
</nav><?php /**PATH C:\laragon\www\empleamusic\resources\views/menu/menu.blade.php ENDPATH**/ ?>
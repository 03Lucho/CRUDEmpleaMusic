
<br>
<br>
<div style="text-align: center; position:absolute:50%">
<br>
<br>
<h2>Agendas</h2>
<div style=" text-align: center">
    <table style="margin:2%;text-align: center; border:2px solid black">
        <tr>
            <td style="border:2px solid black; padding:5px">Nombre Aprendiz</td>
            <td style="border:2px solid black; padding:5px">Nombre Clase</td>
            <td style="border:2px solid black; padding:5px">Fecha Agendada</td>
            <td style="border:2px solid black; padding:5px">Agenda Realizada El:</td>
            <td style="border:2px solid black; padding:5px">Descripcion</td>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
            <td style="border-right:2px solid black; padding:10px"><a href="<?php echo e(route('profesores.perfaprendagend',$agend->idaprendiz)); ?>"><?php echo e($agend->nomapren); ?></a></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($agend->nomclas); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($agend->fechaagendada); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($agend->fechahora); ?></td>
            <td style="border-right:2px solid black; padding:10px"><?php echo e($agend->descripcion); ?></td>
            
            </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </table>
</div>

<?php /**PATH C:\laragon\www\empleamusic\resources\views/profesores/veragendas.blade.php ENDPATH**/ ?>